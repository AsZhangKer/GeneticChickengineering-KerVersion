package net.guizhanss.gcereborn.items.machines;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.api.items.ItemGroup;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.api.recipes.RecipeType;
import io.github.thebusybiscuit.slimefun4.libraries.dough.inventory.InvUtils;
import io.github.thebusybiscuit.slimefun4.libraries.dough.items.ItemUtils;

import me.mrCookieSlime.Slimefun.Objects.SlimefunItem.abstractItems.MachineRecipe;
import me.mrCookieSlime.Slimefun.api.inventory.BlockMenu;

import net.guizhanss.gcereborn.GeneticChickengineering;
import net.guizhanss.gcereborn.items.GCEItems;
import net.guizhanss.gcereborn.utils.ChickenUtils;

/**
 * 基因测序仪 - 用于分析鸡的DNA类型
 * Genetic Sequencer - Used to analyze chicken DNA types
 */
public class GeneticSequencer extends AbstractMachine {

    /**
     * 构造基因测序仪
     * Constructs a Genetic Sequencer
     *
     * @param itemGroup 物品分组
     * @param item Slimefun物品堆
     * @param recipeType 配方类型
     * @param recipe 合成配方
     */
    public GeneticSequencer(ItemGroup itemGroup, SlimefunItemStack item, RecipeType recipeType, ItemStack[] recipe) {
        super(itemGroup, item, recipeType, recipe);
    }

    @Override
    @Nonnull
    public ItemStack getProgressBar() {
        // 使用口袋鸡作为进度条图标
        // Use Pocket Chicken as progress bar icon
        return GCEItems.POCKET_CHICKEN.clone();
    }

    @Override
    @Nullable
    protected MachineRecipe findNextRecipe(@Nonnull BlockMenu menu) {
        var config = GeneticChickengineering.getConfigService();

        // 遍历所有输入槽位
        // Iterate through all input slots
        for (int slot : getInputSlots()) {
            ItemStack item = menu.getItemInSlot(slot);

            // 检查是否为口袋鸡且DNA未学习
            // Check if it's a Pocket Chicken with unknown DNA
            if (!ChickenUtils.isPocketChicken(item) || ChickenUtils.isLearned(item)) {
                continue;
            }

            ItemStack chicken = item.clone();
            // 防止物品堆叠
            // Prevent item stacking
            chicken.setAmount(1);

            ItemStack learnedChicken = ChickenUtils.learnDNA(chicken);

            // =================================================================
            // 修改部分：根据鸡的稀有度决定DNA分析时间
            // Modified: Determine DNA analysis time based on chicken rarity
            // =================================================================
            int baseTime = 4; // 基础时间：20秒（400 ticks） Base time: 20 seconds (400 ticks)

            // 获取鸡的稀有度等级（Tier 0-6，0最稀有）
            // Get chicken rarity level (Tier 0-6, 0 being the rarest)
            int chickenTier = ChickenUtils.getResourceTier(chicken);

            // 越稀有的鸡需要越长的分析时间
            // Rarer chickens require longer analysis time
            // Tier 0（最稀有）：基础时间 × 6 = 2分钟
            // Tier 0 (rarest): base time × 6 = 2 minutes
            // Tier 6（最普通）：基础时间 × 1 = 20秒
            // Tier 6 (most common): base time × 1 = 20 seconds
            int multiplier = 7 - chickenTier; // Tier 0: x7, Tier 1: x6, ..., Tier 6: x1
            int analysisTime = baseTime * multiplier;

            // 设置时间范围限制
            // Set time range limits
            if (analysisTime < 4) analysisTime = 4; // 最少20秒 Minimum 20 seconds
            if (analysisTime > 48) analysisTime = 48; // 最多4分钟（4800 ticks） Maximum 4 minutes (4800 ticks)

            MachineRecipe recipe = new MachineRecipe(
                config.isTest() ? 1 : analysisTime, // 测试模式：1 tick，正常模式：计算出的时间
                new ItemStack[] {chicken},         // Test mode: 1 tick, Normal mode: calculated time
                new ItemStack[] {learnedChicken}   // 输入：未学习的鸡 Input: Unlearned chicken
            );                                     // 输出：已学习的鸡 Output: Learned chicken

            // 检查输出槽是否有足够空间
            // Check if there's enough space in output slots
            if (!InvUtils.fitAll(menu.toInventory(), recipe.getOutput(), getOutputSlots())) {
                continue;
            }

            // 痛苦机制处理
            // Pain mechanism processing
            if (config.isPainEnabled()) {
                if (!ChickenUtils.survivesPain(learnedChicken) && !config.isPainDeathEnabled()) {
                    // 疼痛致死禁用时停止处理
                    // Stop processing when pain death is disabled
                    continue;
                }
                ChickenUtils.possiblyHarm(learnedChicken);
            }

            // 检查鸡是否在分析过程中死亡
            // Check if chicken died during analysis
            if (config.isPainEnabled() && ChickenUtils.getHealth(learnedChicken) <= 0d) {
                ItemUtils.consumeItem(chicken, false);
                menu.getBlock().getWorld().playSound(menu.getLocation(), Sound.ENTITY_CHICKEN_DEATH, 1f, 1f);
                continue;
            }

            // 消耗输入物品
            // Consume input item
            menu.consumeItem(slot, 1);

            return recipe;
        }

        return null;
    }

}
