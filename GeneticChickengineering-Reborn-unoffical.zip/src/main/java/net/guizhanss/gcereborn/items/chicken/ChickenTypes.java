package net.guizhanss.gcereborn.items.chicken;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

import javax.annotation.Nonnull;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.implementation.SlimefunItems;

import net.guizhanss.gcereborn.GeneticChickengineering;
import net.guizhanss.gcereborn.items.GCEItems;
import net.guizhanss.gcereborn.utils.ChickenUtils;

import lombok.experimental.UtilityClass;

@UtilityClass
public final class ChickenTypes {

    private static final Map<Integer, ChickenProduct> TYPES = new LinkedHashMap<>();

    static {
        // ======================= 第1层：基础资源 & 生存物资 =======================
        TYPES.put(63, new ChickenProduct(new ItemStack(Material.STRING)));           // 线
        TYPES.put(62, new ChickenProduct("WATER", GCEItems.WATER_EGG));              // 水蛋
        TYPES.put(61, new ChickenProduct(new ItemStack(Material.SAND)));            // 沙子
        TYPES.put(59, new ChickenProduct(new ItemStack(Material.FLINT)));            // 燧石
        TYPES.put(58, new ChickenProduct(new ItemStack(Material.DRIED_KELP)));       // 干海带（更有用）
        TYPES.put(57, new ChickenProduct(new ItemStack(Material.GUNPOWDER)));        // 火药
        TYPES.put(55, new ChickenProduct(new ItemStack(Material.DIRT)));         // 泥土
        TYPES.put(54, new ChickenProduct(new ItemStack(Material.BAMBOO)));           // 竹子（取代橡木原木）
        TYPES.put(53, new ChickenProduct(new ItemStack(Material.BONE_BLOCK)));        // 骨块
        TYPES.put(51, new ChickenProduct(new ItemStack(Material.EGG)));         //蛋
        TYPES.put(50, new ChickenProduct(new ItemStack(Material.CACTUS)));           // 仙人掌
        TYPES.put(49, new ChickenProduct(new ItemStack(Material.REDSTONE)));         // 红石
        TYPES.put(47, new ChickenProduct(new ItemStack(Material.COBBLESTONE)));      // 圆石
        TYPES.put(46, new ChickenProduct(new ItemStack(Material.ICE)));       // 冰
        TYPES.put(45, new ChickenProduct(new ItemStack(Material.GRAVEL)));           // 沙砾
        TYPES.put(44, new ChickenProduct(new ItemStack(Material.SNOW_BLOCK)));         // 雪
        TYPES.put(43, new ChickenProduct(new ItemStack(Material.TURTLE_EGG)));       // 海龟蛋
        TYPES.put(42, new ChickenProduct(SlimefunItems.TIN_DUST));                   // 锡粉
        TYPES.put(41, new ChickenProduct("LAVA", GCEItems.LAVA_EGG));                // 熔岩蛋
        TYPES.put(39, new ChickenProduct(new ItemStack(Material.SHULKER_SHELL)));    // 潜影壳

// ======================= 第2层：金属 & 工业原料 =======================
        TYPES.put(38, new ChickenProduct(SlimefunItems.MAGNESIUM_DUST));             // 镁粉
        TYPES.put(37, new ChickenProduct(SlimefunItems.COPPER_DUST));                // 铜粉
        TYPES.put(35, new ChickenProduct(new ItemStack(Material.OBSIDIAN)));         // 黑曜石
        TYPES.put(33, new ChickenProduct(SlimefunItems.SULFATE));                    // 硫酸盐
        TYPES.put(31, new ChickenProduct(new ItemStack(Material.LIGHT)));        //光
        TYPES.put(30, new ChickenProduct(new ItemStack(Material.SPONGE)));           // 海绵
        TYPES.put(29, new ChickenProduct(new ItemStack(Material.SUGAR)));            // 糖
        TYPES.put(28, new ChickenProduct(new ItemStack(Material.CAKE)));             // 蛋糕
        TYPES.put(27, new ChickenProduct(new ItemStack(Material.LEATHER)));      //皮革
        TYPES.put(26, new ChickenProduct(SlimefunItems.ZINC_DUST));                  // 锌粉
        TYPES.put(25, new ChickenProduct(SlimefunItems.SILVER_DUST));                // 银粉
        TYPES.put(24, new ChickenProduct(new ItemStack(Material.PHANTOM_MEMBRANE))); // 幻翼膜
        TYPES.put(23, new ChickenProduct(new ItemStack(Material.SUGAR_CANE)));       // 甘蔗
        TYPES.put(22, new ChickenProduct(SlimefunItems.GOLD_DUST));                  // 金粉
        TYPES.put(21, new ChickenProduct(SlimefunItems.IRON_DUST));                  // 铁粉

// ======================= 第3层：稀有矿物 & 魔法材料 =======================
        TYPES.put(20, new ChickenProduct(new ItemStack(Material.TROPICAL_FISH)));      //鱼
        TYPES.put(19, new ChickenProduct("IRON", new ItemStack(Material.IRON_INGOT))); // 铁锭
        TYPES.put(18, new ChickenProduct(new ItemStack(Material.EXPERIENCE_BOTTLE))); // 经验瓶
        TYPES.put(17, new ChickenProduct(new ItemStack(Material.GHAST_TEAR)));       // 恶魂之泪
        TYPES.put(16, new ChickenProduct(SlimefunItems.SALT)); //NaCl
        TYPES.put(15, new ChickenProduct(new ItemStack(Material.COAL)));             // 煤炭
        TYPES.put(14, new ChickenProduct("LAPIS", new ItemStack(Material.LAPIS_LAZULI))); // 青金石
        TYPES.put(13, new ChickenProduct(new ItemStack(Material.GLOWSTONE_DUST)));   // 荧石粉（取代玻璃）
        TYPES.put(12, new ChickenProduct(new ItemStack(Material.SOUL_SAND)));        // 灵魂沙
        TYPES.put(11, new ChickenProduct(new ItemStack(Material.NETHERRACK)));       // 下界岩
        TYPES.put(10, new ChickenProduct(new ItemStack(Material.QUARTZ)));           // 石英
        TYPES.put(9, new ChickenProduct(new ItemStack(Material.BLAZE_ROD)));         // 烈焰棒
        TYPES.put(8, new ChickenProduct(new ItemStack(Material.PRISMARINE_SHARD)));  // 海晶碎片
        TYPES.put(7, new ChickenProduct("GOLD", new ItemStack(Material.GOLD_INGOT))); // 金锭

// ======================= 第4层：高级合金 & 稀有物品 =======================
        TYPES.put(6, new ChickenProduct(new ItemStack(Material.SHROOMLIGHT)));       // 菌光体
        TYPES.put(5, new ChickenProduct(new ItemStack(Material.NETHERITE_SCRAP)));         // 下界合金碎片
        TYPES.put(4, new ChickenProduct(new ItemStack(Material.DIAMOND)));           // 钻石 ⭐ 保持不变
        TYPES.put(3, new ChickenProduct(new ItemStack(Material.SLIME_BALL)));        // 粘液球
        TYPES.put(2, new ChickenProduct(SlimefunItems.REDSTONE_ALLOY));              // 红石合金锭 ⭐ 保持不变
        TYPES.put(1, new ChickenProduct(new ItemStack(Material.NETHERITE_INGOT)));   // 下界合金锭 ⭐ 保持不变
        TYPES.put(0, new ChickenProduct(SlimefunItems.REINFORCED_ALLOY_INGOT));      // 强化合金锭 ⭐ 保持不变

// ======================= 第5层：史诗级物品 =======================
// 添加一些新的高价值物品
        TYPES.put(34, new ChickenProduct("NETHERITE", new ItemStack(Material.SOUL_SOIL))); // 灵魂土 ⭐ 保持不变
        TYPES.put(36, new ChickenProduct(new ItemStack(Material.NETHER_WART)));      // 下界疣
        TYPES.put(40, new ChickenProduct(new ItemStack(Material.MAGMA_CREAM)));      // 岩浆膏
        TYPES.put(48, new ChickenProduct(new ItemStack(Material.ECHO_SHARD)));       // 回响碎片（1.19新物品）
        TYPES.put(52, new ChickenProduct(SlimefunItems.ALUMINUM_DUST));              // 铝粉
        TYPES.put(56, new ChickenProduct(SlimefunItems.LEAD_DUST));                  // 铅粉
        TYPES.put(60, new ChickenProduct(new ItemStack(Material.NAUTILUS_SHELL)));   // 鹦鹉螺壳（取代粘液球）
    }

    @Nonnull
    public static ChickenProduct get(int typing) {
        return TYPES.get(typing);
    }

    @Nonnull
    public static String getName(int typing) {
        return TYPES.get(typing).getName();
    }

    @Nonnull
    public static String getDisplayName(int typing) {
        return TYPES.get(typing).getProductName();
    }

    @Nonnull
    public static ItemStack getProduct(int typing) {
        return TYPES.get(typing).getProduct();
    }

    public static void registerChickens() {
        for (int i = TYPES.size() - 1; i >= 0; i--) {
            ChickenUtils.createProductDisplay(i);
        }
        GeneticChickengineering.log(Level.INFO,
            GeneticChickengineering.getLocalization().getString("console.load.chickens", TYPES.size()));
    }

}
