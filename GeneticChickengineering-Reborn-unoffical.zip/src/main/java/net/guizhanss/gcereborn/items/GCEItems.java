package net.guizhanss.gcereborn.items;

import org.bukkit.Material;

import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.core.attributes.MachineTier;
import io.github.thebusybiscuit.slimefun4.core.attributes.MachineType;
import io.github.thebusybiscuit.slimefun4.utils.LoreBuilder;

import net.guizhanss.gcereborn.GeneticChickengineering;

import lombok.experimental.UtilityClass;

@UtilityClass
public final class GCEItems {

    // 物品常量定义
    public static final SlimefunItemStack POCKET_CHICKEN;        // 口袋鸡（精灵球-内含小鸡_x1）
    public static final SlimefunItemStack CHICKEN_NET;           // 捉鸡网（空的精灵球）
    public static final SlimefunItemStack WATER_EGG;             // 水蛋（水刷怪蛋）
    public static final SlimefunItemStack LAVA_EGG;              // 岩浆蛋（岩浆刷怪蛋）
    public static final SlimefunItemStack GENETIC_SEQUENCER;     // 基因测序仪
    public static final SlimefunItemStack EXCITATION_CHAMBER;    // 普通压榨机
    public static final SlimefunItemStack EXCITATION_CHAMBER_2;  // 高效压榨机
    public static final SlimefunItemStack PRIVATE_COOP;          // 鸡笼
    public static final SlimefunItemStack RESTORATION_CHAMBER;   // 休息室
    public static final SlimefunItemStack GROWTH_CHAMBER;        // 成长室

    private static final String LORE_RIGHT_CLICK_TO_USE;  // "右键点击以使用"的本地化字符串

    static {
        // 从语言文件获取"右键点击以使用"的文本
        LORE_RIGHT_CLICK_TO_USE = GeneticChickengineering.getLocalization().getString("lores.right-click-to-use");

        // 开始初始化物品
        // @formatter:off
        POCKET_CHICKEN = GeneticChickengineering.getLocalization().getItem(
            "POCKET_CHICKEN",  // 物品ID，对应messages.yml中的items.POCKET_CHICKEN
            "8f266f1bcd32831d692bda473afd3fa05c3a8e7ab2bb470d88ff81e38f67ab7a"  // 新的自定义头颅纹理Base64
        );

        CHICKEN_NET = GeneticChickengineering.getLocalization().getItem(
            "CHICKEN_NET",      // 物品ID
            Material.COBWEB,    // 材质：蜘蛛网
            "",                 // 额外描述（空）
            LORE_RIGHT_CLICK_TO_USE  // lore：右键点击以使用
        );

        WATER_EGG = GeneticChickengineering.getLocalization().getItem(
            "WATER_EGG",              // 物品ID
            Material.TURTLE_SPAWN_EGG, // 材质：海龟刷怪蛋
            "",                        // 额外描述
            LORE_RIGHT_CLICK_TO_USE   // lore：右键点击以使用
        );

        LAVA_EGG = GeneticChickengineering.getLocalization().getItem(
            "LAVA_EGG",               // 物品ID
            Material.STRIDER_SPAWN_EGG, // 材质：炽足兽刷怪蛋
            "",                         // 额外描述
            LORE_RIGHT_CLICK_TO_USE    // lore：右键点击以使用
        );

        // ============================================================
        // 基因测序仪 - 根据你的修改，DNA分析时间较长
        // ============================================================
        GENETIC_SEQUENCER = GeneticChickengineering.getLocalization().getItem(
            "GENETIC_SEQUENCER",  // 物品ID
            Material.SMOKER,      // 材质：烟熏炉
            "",                   // 额外描述
            LoreBuilder.machine(MachineTier.MEDIUM, MachineType.MACHINE),  // 机器等级：中级
            LoreBuilder.powerPerSecond(6),  // 电力消耗：6J/s（原值）
            "&7DNA分析时间：&e30-90秒",      // 新增：显示分析时间
            "&7稀有度越高，分析时间越长"      // 新增：说明
        );

        // ============================================================
        // 普通压榨机 - 效率较低，耗电较高
        // 原电力：10J/s，现改为8J/s（根据你的Items.java修改）
        // ============================================================
        EXCITATION_CHAMBER = GeneticChickengineering.getLocalization().getItem(
            "EXCITATION_CHAMBER",  // 物品ID
            Material.BLAST_FURNACE, // 材质：高炉
            "",                     // 额外描述
            LoreBuilder.machine(MachineTier.MEDIUM, MachineType.MACHINE),  // 机器等级：中级
            LoreBuilder.powerPerSecond(8),  // 电力消耗：8J/s（修改后）
            "&7处理时间：&e约1分钟",         // 新增：显示处理时间
            "&c效率较低，耗电较高"           // 新增：说明缺点
        );

        // ============================================================
        // 高效压榨机 - 效率等于原普通版，耗电更高
        // 原电力：15J/s，现改为15J/s（根据你的Items.java修改）
        // ============================================================
        EXCITATION_CHAMBER_2 = GeneticChickengineering.getLocalization().getItem(
            "EXCITATION_CHAMBER_2",  // 物品ID
            Material.BLAST_FURNACE,   // 材质：高炉
            "",                       // 额外描述
            LoreBuilder.machine(MachineTier.ADVANCED, MachineType.MACHINE),  // 机器等级：高级
            LoreBuilder.powerPerSecond(15),  // 电力消耗：15J/s（修改后）
            "&7处理时间：&e约14秒",           // 新增：显示处理时间
            "&a效率UP！",             // 新增：说明优点
            "&c耗电更高"                     // 新增：说明缺点
        );

        // ============================================================
        // 鸡笼 - 繁殖时间缩短为1秒，需要种子
        // 原电力：2J/s，保持不变
        // ============================================================
        PRIVATE_COOP = GeneticChickengineering.getLocalization().getItem(
            "PRIVATE_COOP",    // 物品ID
            Material.BEEHIVE,  // 材质：蜂箱
            "",                // 额外描述
            LoreBuilder.machine(MachineTier.MEDIUM, MachineType.MACHINE),  // 机器等级：中级
            LoreBuilder.powerPerSecond(2),  // 电力消耗：2J/s
            "&7繁殖时间：&e1秒",              // 新增：显示繁殖时间
            "&7需要：&e2个作物种子",          // 新增：显示需求
            "&c5%几率繁殖失败",               // 新增：显示风险
            "&4失败将失去母本鸡"              // 新增：显示失败后果
        );

        // ============================================================
        // 休息室 - 治疗受伤的鸡
        // 原电力：4J/s，保持不变
        // ============================================================
        RESTORATION_CHAMBER = GeneticChickengineering.getLocalization().getItem(
            "RESTORATION_CHAMBER",  // 物品ID
            Material.PINK_SHULKER_BOX,  // 材质：粉色潜影盒
            "",                         // 额外描述
            LoreBuilder.machine(MachineTier.MEDIUM, MachineType.MACHINE),  // 机器等级：中级
            LoreBuilder.powerPerSecond(4),  // 电力消耗：4J/s
            "&7每颗种子恢复：&e0.25生命值",    // 新增：显示治疗效果
            "&7鸡最大生命值：&e4.0"           // 新增：显示生命值信息
        );

        // ============================================================
        // 成长室 - 加速小鸡成长
        // 原电力：20J/s，保持不变
        // ============================================================
        GROWTH_CHAMBER = GeneticChickengineering.getLocalization().getItem(
            "GROWTH_CHAMBER",       // 物品ID
            Material.GREEN_SHULKER_BOX,  // 材质：绿色潜影盒
            "",                           // 额外描述
            LoreBuilder.machine(MachineTier.ADVANCED, MachineType.MACHINE),  // 机器等级：高级
            LoreBuilder.powerPerSecond(20)  // 电力消耗：20J/s
        );
        // @formatter:on
    }
}
