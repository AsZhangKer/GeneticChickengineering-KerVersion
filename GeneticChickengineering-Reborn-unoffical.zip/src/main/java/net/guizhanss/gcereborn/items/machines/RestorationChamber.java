package net.guizhanss.gcereborn.items.machines;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.api.items.ItemGroup;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.api.recipes.RecipeType;
import io.github.thebusybiscuit.slimefun4.libraries.dough.inventory.InvUtils;
import io.github.thebusybiscuit.slimefun4.libraries.dough.items.ItemUtils;

import me.mrCookieSlime.Slimefun.Objects.SlimefunItem.abstractItems.MachineRecipe;
import me.mrCookieSlime.Slimefun.api.inventory.BlockMenu;

import net.guizhanss.gcereborn.GeneticChickengineering;
import net.guizhanss.gcereborn.items.GCEItems;
import net.guizhanss.gcereborn.utils.ChickenUtils;

/**
 * 休息室 - 用于治疗受伤的鸡
 * Restoration Chamber - Used to heal injured chickens
 */
public class RestorationChamber extends AbstractMachine {

    /**
     * 构造休息室
     * Constructs a Restoration Chamber
     *
     * @param itemGroup 物品分组
     * @param item Slimefun物品堆
     * @param recipeType 配方类型
     * @param recipe 合成配方
     */
    public RestorationChamber(ItemGroup itemGroup, SlimefunItemStack item, RecipeType recipeType, ItemStack[] recipe) {
        super(itemGroup, item, recipeType, recipe);
    }

    @Override
    @Nonnull
    public ItemStack getProgressBar() {
        // 使用口袋鸡作为进度条图标
        // Use Pocket Chicken as progress bar icon
        return GCEItems.POCKET_CHICKEN.clone();
    }

    @Override
    @Nullable
    protected MachineRecipe findNextRecipe(@Nonnull BlockMenu menu) {
        var config = GeneticChickengineering.getConfigService();

        ItemStack chicken = null;
        ItemStack seed = null;

        // 遍历输入槽位，寻找鸡和种子
        // Iterate through input slots, looking for chicken and seeds
        for (int slot : getInputSlots()) {
            ItemStack item = menu.getItemInSlot(slot);

            if (item == null || item.getType() == Material.AIR) {
                continue;
            }

            if (ChickenUtils.isPocketChicken(item)) {
                chicken = item;  // 找到鸡 Found chicken
            } else if (ChickenUtils.isFood(item)) {
                seed = item;     // 找到种子（鸡的食物） Found seeds (chicken food)
            }
        }

        // 需要同时有鸡和种子
        // Need both chicken and seeds
        if (chicken == null || seed == null) {
            return null;
        }

        // 获取鸡的当前生命值
        // Get chicken's current health
        double health = ChickenUtils.getHealth(chicken);

        // 获取种子数量
        // Get seed amount
        int seedAmount = seed.getAmount();
        int toConsume = 0;  // 需要消耗的种子数量 Seeds to consume

        // 计算需要多少种子来完全治疗这只鸡
        // Calculate how many seeds are needed to fully heal this chicken
        while (seedAmount > 0 && health < 4d) {
            seedAmount--;
            toConsume++;
            health = health + 0.25;  // 每颗种子恢复0.25生命值 Each seed restores 0.25 health
        }

        // 如果不需要治疗（生命值已满）
        // If no healing is needed (health is already full)
        if (toConsume == 0) {
            return null;
        }

        // 创建配方输入物品
        // Create recipe input items
        ItemStack recipeSeeds = seed.clone();
        recipeSeeds.setAmount(toConsume);

        ItemStack recipeChick = chicken.clone();
        ChickenUtils.heal(recipeChick, toConsume * 0.25);  // 治疗鸡 Heal the chicken

        // 创建治疗配方
        // Create healing recipe
        MachineRecipe recipe = new MachineRecipe(
            config.isTest() ? 1 : config.getHealRate() * toConsume,  // 治疗时间 = 基础治疗时间 × 消耗的种子数
            new ItemStack[] {recipeSeeds, chicken.clone()},         // Healing time = base heal rate × seeds consumed
            new ItemStack[] {recipeChick}                           // 输入：种子和受伤的鸡 Input: seeds and injured chicken
        );                                                          // 输出：治疗后的鸡 Output: healed chicken

        // 检查输出槽是否有足够空间
        // Check if there's enough space in output slots
        if (!InvUtils.fitAll(menu.toInventory(), recipe.getOutput(), getOutputSlots())) {
            return null;
        }

        // 消耗输入物品
        // Consume input items
        ItemUtils.consumeItem(chicken, false);           // 消耗鸡（整个物品） Consume chicken (entire item)
        ItemUtils.consumeItem(seed, toConsume, false);   // 消耗指定数量的种子 Consume specified amount of seeds

        return recipe;
    }
}
