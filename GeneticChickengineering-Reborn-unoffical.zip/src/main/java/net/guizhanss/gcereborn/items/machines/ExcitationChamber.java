package net.guizhanss.gcereborn.items.machines;

import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.api.items.ItemGroup;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.api.recipes.RecipeType;
import io.github.thebusybiscuit.slimefun4.core.machines.MachineProcessor;
import io.github.thebusybiscuit.slimefun4.implementation.operations.CraftingOperation;
import io.github.thebusybiscuit.slimefun4.libraries.dough.inventory.InvUtils;
import io.github.thebusybiscuit.slimefun4.libraries.dough.items.ItemUtils;
import io.github.thebusybiscuit.slimefun4.utils.ChestMenuUtils;

import me.mrCookieSlime.Slimefun.Objects.SlimefunItem.abstractItems.MachineRecipe;
import me.mrCookieSlime.Slimefun.api.BlockStorage;
import me.mrCookieSlime.Slimefun.api.inventory.BlockMenu;
import me.mrCookieSlime.Slimefun.api.inventory.BlockMenuPreset;

import net.guizhanss.gcereborn.GeneticChickengineering;
import net.guizhanss.gcereborn.items.GCEItems;
import net.guizhanss.gcereborn.utils.GuiItems;
import net.guizhanss.gcereborn.utils.ChickenUtils;

public class ExcitationChamber extends AbstractMachine {

    private static final int[] BACKGROUND = new int[] {
        0, 1, 2, 6, 7, 8,
        9, 10, 11, 15, 16, 17,
        18, 19, 20, 21, 23, 24,
        25, 26
    };
    private static final int[] INPUT_BORDER = new int[] {3, 5, 12, 13, 14};
    private static final int[] OUTPUT_BORDER = new int[] {27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 44};
    private static final int[] INPUT_SLOTS = new int[] {4};
    private static final int[] OUTPUT_SLOTS = new int[] {37, 38, 39, 40, 41, 42, 43};

    private final double processingTimeMultiplier;

    public ExcitationChamber(ItemGroup itemGroup, SlimefunItemStack item, RecipeType recipeType, ItemStack[] recipe) {
        this(itemGroup, item, recipeType, recipe, 1.0); // 默认倍率1.0
    }

    public ExcitationChamber(ItemGroup itemGroup, SlimefunItemStack item, RecipeType recipeType, ItemStack[] recipe, double processingTimeMultiplier) {
        super(itemGroup, item, recipeType, recipe);
        this.processingTimeMultiplier = processingTimeMultiplier;
    }

    @Override
    @Nonnull
    public ItemStack getProgressBar() {
        return GCEItems.POCKET_CHICKEN.clone();
    }

    @Override
    public int[] getInputSlots() {
        return INPUT_SLOTS;
    }

    @Override
    public int[] getOutputSlots() {
        return OUTPUT_SLOTS;
    }

    @Override
    protected void constructMenu(@Nonnull BlockMenuPreset preset) {
        for (int i : BACKGROUND) {
            preset.addItem(i, ChestMenuUtils.getBackground(), ChestMenuUtils.getEmptyClickHandler());
        }

        for (int i : INPUT_BORDER) {
            preset.addItem(i, ChestMenuUtils.getInputSlotTexture(), ChestMenuUtils.getEmptyClickHandler());
        }

        for (int i : OUTPUT_BORDER) {
            preset.addItem(i, ChestMenuUtils.getOutputSlotTexture(), ChestMenuUtils.getEmptyClickHandler());
        }

        preset.addItem(INFO_SLOT, GuiItems.BLACK_PANE, ChestMenuUtils.getEmptyClickHandler());

        for (int i : getOutputSlots()) {
            preset.addMenuClickHandler(i, (p, slot, cursor, action) -> cursor != null && !cursor.getType().isAir());
        }
    }

    @Override
    protected void tick(@Nonnull Block b) {
        super.tick(b);
        BlockMenu inv = BlockStorage.getInventory(b);
        MachineProcessor<CraftingOperation> processor = getMachineProcessor();
        if (processor.getOperation(b) != null && findNextRecipe(inv) == null) {
            processor.endOperation(b);
            inv.replaceExistingItem(INFO_SLOT, GuiItems.BLACK_PANE);
        }
    }

    @Override
    @Nullable
    protected MachineRecipe findNextRecipe(@Nonnull BlockMenu menu) {
        var config = GeneticChickengineering.getConfigService();
        for (int slot : getInputSlots()) {
            ItemStack chicken = menu.getItemInSlot(slot);

            if (!ChickenUtils.isPocketChicken(chicken) || !ChickenUtils.isAdult(chicken)) {
                continue;
            }

            // Set the progress bar to always be the resource, since players
            // can abort the recipe if they know the egg is coming
            ItemStack resourceIcon = ChickenUtils.getResource(chicken);

            ItemStack chickResource;
            if (ThreadLocalRandom.current().nextInt(100) < config.getResourceFailRate()) {
                chickResource = new ItemStack(Material.EGG);
            } else {
                chickResource = resourceIcon.clone();
            }

            /* 修改的速度计算公式：
             * 原公式：speed = (基础时间 + 鸡等级 - 2×DNA强度) / 机器速度
             * 新公式：speed = (基础时间 + 鸡等级 - 2×DNA强度) × 处理时间倍率 / 机器速度
             *
             * 原基础时间：14秒
             * 要达到约1分钟处理时间，需要约4.3倍时间倍率
             *
             * 实际时间范围（普通版，时间倍率4.3）：
             * Tier 0: (14+0-2×6)×4.3 = 8.6秒 ≈ 9秒
             * Tier 6: (14+6-2×0)×4.3 = 86秒 ≈ 1分26秒
             * 平均约1分钟左右
             */
            int baseCalculation = config.getResourceBaseTime() +
                ChickenUtils.getResourceTier(chicken) -
                2 * ChickenUtils.getDNAStrength(chicken);

            // 应用处理时间倍率
            int speed = (int)(baseCalculation * processingTimeMultiplier / getSpeed());

            // 确保最小处理时间为1秒（Slimefun要求）
            if (speed < 1) {
                speed = 1;
            }

            MachineRecipe recipe = new MachineRecipe(
                config.isTest() ? 1 : speed,
                new ItemStack[] {chicken},
                new ItemStack[] {chickResource}
            );
            if (!InvUtils.fitAll(menu.toInventory(), recipe.getOutput(), getOutputSlots())) {
                continue;
            }

            if (config.isPainEnabled()) {
                if (!ChickenUtils.survivesPain(chicken) && !config.isPainDeathEnabled()) {
                    continue;
                }
                ChickenUtils.possiblyHarm(chicken);
                if (ChickenUtils.getHealth(chicken) <= 0d) {
                    ItemUtils.consumeItem(chicken, false);
                    GeneticChickengineering.getScheduler().run(() ->
                        menu.getLocation().getWorld().playSound(menu.getLocation(), Sound.ENTITY_CHICKEN_DEATH, 1f, 1f)
                    );
                    continue;
                }
            }

            return recipe;
        }

        return null;
    }

    // 获取处理时间倍率的方法（可用于显示在lore中）
    public double getProcessingTimeMultiplier() {
        return processingTimeMultiplier;
    }
}
