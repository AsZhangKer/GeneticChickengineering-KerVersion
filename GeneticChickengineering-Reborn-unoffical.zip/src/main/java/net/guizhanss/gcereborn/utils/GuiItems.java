package net.guizhanss.gcereborn.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.libraries.dough.items.CustomItemStack;

import lombok.experimental.UtilityClass;

@UtilityClass
public final class GuiItems {

    public static final ItemStack BLACK_PANE = new CustomItemStack(Material.BLACK_STAINED_GLASS_PANE, " ");
}
