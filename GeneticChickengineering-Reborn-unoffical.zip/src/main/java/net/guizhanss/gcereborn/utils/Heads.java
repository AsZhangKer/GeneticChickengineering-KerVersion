package net.guizhanss.gcereborn.utils;

import org.bukkit.inventory.ItemStack;

import io.github.thebusybiscuit.slimefun4.utils.SlimefunUtils;

import lombok.Getter;

@Getter
public enum Heads {
    // https://minecraft-heads.com/custom-heads/animals/336-chicken
    CHICKEN("8f266f1bcd32831d692bda473afd3fa05c3a8e7ab2bb470d88ff81e38f67ab7a");

    private final String texture;

    Heads(String texture) {
        this.texture = texture;
    }

    public ItemStack getItem() {
        return SlimefunUtils.getCustomHead(texture);
    }

    public String getTexture() {
        return texture;
    }
}
