# Localization

This addon is available in the following languages:

- English (US) `en-US`
- 简体中文 `zh-CN`
- 繁體中文 `zh-TW`

You can change the `options.lang` in `config.yml` to change the language of this addon.

## Contribution

If you want to contribute your translation, please visit our [Crowdin](https://crowdin.com/project/gcereborn) page, and submit your translation.

If your language is not there, please contact @ybw0014 in Slimefun Addon Community's Discord server.
